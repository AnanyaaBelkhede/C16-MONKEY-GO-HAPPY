var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["a6870703-0124-47f7-acff-dbe905f5014c","5ce44e39-12ac-4a66-88cf-a87a0ed6a180","33841f90-7a53-4346-b956-e51d1961959b","f80d4823-12c1-4c09-a431-85f46555df31"],"propsByKey":{"a6870703-0124-47f7-acff-dbe905f5014c":{"name":"monkey","sourceUrl":null,"frameSize":{"x":560,"y":614},"frameCount":10,"looping":true,"frameDelay":4,"version":"00ZyRg7Ht1_lXVv9Z_N1848Qlur0tqGc","loadedFromSource":true,"saved":true,"sourceSize":{"x":1680,"y":1842},"rootRelativePath":"assets/a6870703-0124-47f7-acff-dbe905f5014c.png"},"5ce44e39-12ac-4a66-88cf-a87a0ed6a180":{"name":"Banana","sourceUrl":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/5ce44e39-12ac-4a66-88cf-a87a0ed6a180.png","frameSize":{"x":1080,"y":1080},"frameCount":1,"looping":true,"frameDelay":4,"version":"rn5F31wt_T9JWJ9DtsxY5YndfteTYosn","loadedFromSource":true,"saved":true,"sourceSize":{"x":1080,"y":1080},"rootRelativePath":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/5ce44e39-12ac-4a66-88cf-a87a0ed6a180.png"},"33841f90-7a53-4346-b956-e51d1961959b":{"name":"Stone","sourceUrl":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/33841f90-7a53-4346-b956-e51d1961959b.png","frameSize":{"x":512,"y":512},"frameCount":1,"looping":true,"frameDelay":4,"version":"JmzJjDnwCx0uDCTc5psQjIxLxBaX2Fbk","loadedFromSource":true,"saved":true,"sourceSize":{"x":512,"y":512},"rootRelativePath":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/33841f90-7a53-4346-b956-e51d1961959b.png"},"f80d4823-12c1-4c09-a431-85f46555df31":{"name":"b","sourceUrl":null,"frameSize":{"x":280,"y":210},"frameCount":1,"looping":true,"frameDelay":12,"version":"8eHSRxbxslahKwDWSlYR9JB6MdEXet97","loadedFromSource":true,"saved":true,"sourceSize":{"x":280,"y":210},"rootRelativePath":"assets/f80d4823-12c1-4c09-a431-85f46555df31.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

//creating sprites
var scene = createSprite(200,200,400,400);
scene.setAnimation("b");
scene.scale = 2;

var monkey = createSprite(60,300,20,20);
monkey.setAnimation("monkey");
monkey.scale = 0.16;

var ground = createSprite(200,360,400,20);
ground.visible = false;

var stoneG = createGroup();
var bananaG = createGroup();

stroke("black");
  textSize(20);
  fill("black");

function draw(){
  background("white");
    
//giving x velocity to scene
  scene.velocityX = -2;
  
if(scene.x <50){
  scene.x = scene.width/2;
}

//jump when the space key is pressed
  if(keyDown("space")){
      monkey.velocityY = -12 ;
      playSound("assets/category_jump/classic_jump_4.mp3");
    }
    
    //add gravity
    monkey.velocityY = monkey.velocityY + 0.8;
  
  monkey.collide(ground);
  spawnStone();
  spawnBanana();
 
  drawSprites();
}

function spawnStone(){
  if(World.frameCount % 300 === 0) {
  var stone = createSprite(0,randomNumber(340,345),10,10);
  stone.x = randomNumber(400,400);
  stone.setAnimation("Stone");
  stone.scale = 0.2;
  stone.velocityX = -3;
  stone.lifetime = 150;
  stoneG.add(stone);

}

}

function spawnBanana(){
  if(World.frameCount % 80 === 0) {
  var banana = createSprite(0,randomNumber(340,345),10,10);
  banana.x = randomNumber(200,400);
  banana.y = randomNumber(120,200);
  banana.setAnimation("Banana");
  banana.scale = 0.05;
  banana.velocityX = -3;
  banana.lifetime = 150;
  bananaG.add(banana);

}
}




// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
